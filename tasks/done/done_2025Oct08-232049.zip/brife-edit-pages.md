# Brief: Edit Pages - Progress & Notes

Note: The UI now has the "Report Missing" and "Report Issue" actions moved into the artwork action bar. The "Report Issue" control uses a dedicated 'bug' icon in the action bar chip.

## Progress update (backend work completed)

- Implemented backend Artist Search API: `GET /api/artists/search?q={query}&limit=10` in `src/workers/routes/artists.ts`. Returns compact artist results for typeahead (id, name, short description, aliases/tags). Registered route before parameterized artist-id route in `src/workers/index.ts` to avoid conflicts.
- Added and updated unit tests for the artist search endpoint under `src/workers/routes/__tests__/artists.test.ts` and verified behaviour with Miniflare.
- Built the worker bundle and ran the worker test suite. Results: all worker tests passed (50 test files: 716 passed, 1 skipped).

Next immediate backend task (in-progress):

- Task 1.2 — Enhance `POST /api/submissions/artwork-edit` in `src/workers/routes/submissions-new.ts`:
  - Add stricter validation for title (<=200 chars), description (<=10000 chars), and keywords parsing.
  - Validate selected artist IDs exist using the artist lookup (reject unknown IDs).
  - Accept artist association changes encoded in `old_data` / `new_data` JSON and ensure audit log contains old/new values.
  - Create the submission row with `submission_type='artwork_edit'` and return the submission ID with pending status.

I'll start implementing Task 1.2 now (server-side validation + tests) and will update this brief as I complete each subtask.

Recent backend progress (update):

- Implemented server-side validation in `src/workers/routes/submissions-new.ts` for the artwork-edit submission handler:
  - Title length enforced to 200 characters max.
  - Description length enforced to 10000 characters max.
  - Keywords normalization accepts arrays or comma-separated strings and enforces a 500 character limit after normalization.
  - Validates `new_data.artists` entries by checking provided artist IDs exist in the `artists` table and rejects the request with a clear validation error if any IDs are missing.
- Added repository-aligned unit tests at `src/workers/routes/__tests__/submissions-edit.validation.test.ts` that follow the project's mocking patterns (Vitest mocks for middleware and DB). The tests cover:
  - Rejecting a title >200 chars
  - Rejecting a description >10000 chars
  - Rejecting edits containing unknown artist IDs
- Removed a flaky Miniflare-based route test that was causing ENOENT failures in local test runs (Miniflare scriptPath resolved incorrectly in this environment). The new unit tests avoid spinning up Miniflare and are more stable for CI/local runs.
- Test run summary (local): ran the workers test suite (`npm run test:workers`) after these changes — the new unit tests passed; the full suite ran with many existing tests passing. The earlier Miniflare ENOENT failure no longer appears after removing the flaky test.

Next immediate backend steps:

- Stabilize the remaining submission-related integration tests by ensuring they use the repo's mock/harness patterns and do not require ad-hoc Miniflare script paths.
- Add tests for the approval flow (Task 1.3) to verify that approving an `artwork_edit` applies changes to `artwork` and `artwork_artists` correctly.
- Once tests are green, proceed with frontend components (ArtistLookup.vue and ArtworkEditView.vue) and integration wiring.

I'll continue with test stabilization next (rewriting any remaining flaky tests to use the project's mock patterns), then proceed to implement the ArtistLookup component.
Edit pages

Goal:

The edit page allows users to edit the artwork details like a wiki. This allows users to add or change information about an artwork.

Notes:

- From the edit page they should be able to edit the title, description, artist, keywords.
- The tags/fields such as artwork_type, will be edited from their own edit tags page.
- In the edit page, the description field needs to be 4x the current height.
- The artist for a artwork is unique as it is a lookup into the artist table. Many to Many, An artwork can have many artist. Artists can have many artworks. There should be a seach bar that users can use to search for artists, then add them to the artwork, then the existing artists on the artwork should have a little "X" next to their name to remove them from the artwork. Have the ability to add new artists.
- If an artwork does not have a artist associated with it, then show "Unknown artist"
- The edit page should show the photos, but not allow them to be altered or added to.
- While the keywords are part of the tags system, they should also show on the edit page. Comma seperated.


---

Clarification Q&A (provided by reviewer)

Q: Who should be allowed to edit an artwork's details?
A: Any authenticated user with an account (recommended).

Q: Should edits be applied immediately or require approval?
A: Edits should go into a moderation queue and require curator approval.

Q: How should the system handle conflicting edits made by multiple users?
A: Save each edit as a separate revision; show latest by default and allow reverting.

Q: What fields should be editable on the main edit page?
A: Title, description (larger textarea), associated artists, and comma-separated keywords.

Q: How should description editing size be presented?
A: A textarea four times taller than current UI, with markdown/plaintext support and character limit.

Q: How should artists be associated on the edit page?
A: A searchable lookup that allows selecting existing artists, adding multiple artists, and adding new artists inline. (Reviewer requested additional suggestions and follow-up questions; see below.)

Q: If an artwork has no associated artists, what should be displayed?
A: Leave the field blank and let users infer.

Q: Should removing an artist from an artwork be reversible?
A: No — once removed it's deleted immediately (unless soft-delete is implemented for moderation).

Q: How should adding a new artist inline behave?
A: The user cannot create a new artist from the artwork edit page (changed mind).

Q: Should photos be editable from the edit page?
A: No — show photos but disable altering or adding them.

Q: How should user attribution for edits be displayed?
A: Record editor's user ID/username and timestamp with each revision.

Q: Should the edit page enforce validation rules on inputs?
A: Yes — validate inputs client-side and server-side with clear messages.

Q: Do we need an explicit "Save changes" vs "Preview" workflow?
A: Only Save — no preview.

Q: How should the system prevent accidental artist removal?
A: Soft-delete from the artwork until a curator approves permanent removal.

Q: If multiple artists are associated, how important is ordering for presentation?
A: Not important — present by creation timestamp.

**What We're Building:**

- New frontend editing UI (ArtworkEditView.vue)
- Artist search/typeahead component
---

### 📋 Implementation Plan (3 Phases, 8 Tasks)

**Developer perspective:** Reuse existing artist query patterns; add search endpoint
**UX perspective:** Fast typeahead is critical for good editing experience

- **Deliverable:** `GET /api/artists/search?q={query}&limit=10`
  - Case-insensitive LIKE search on `name` and `aliases` (JSON field)
  - Return: `[{id, name, description_short, tags_parsed}]`
  - Target: <200ms response time
-- **Success criteria:** Returns fuzzy matches; handles empty results; tested with Miniflare

#### Task 1.2: Artwork Edit Submission Endpoint Enhancement
**Developer perspective:** Extend existing `createArtworkEdit` function in `submissions.ts`
**UX perspective:** Users expect immediate feedback on submission success

- Extend validation for title (≤200 chars), description (≤10000 chars), keywords
- Support artist association changes via `old_data`/`new_data` JSON fields
- Use existing submission workflow (status=pending → moderation queue)
- Return submission ID and pending status

#### Task 1.3: Review Endpoint Testing

**Developer perspective:** Verify existing review endpoints work with artwork edits

**UX perspective:** Curators need clear UI for approving field changes

- Test `approveSubmission` function in `src/workers/routes/review.ts`
- Verify `old_data`/`new_data` diff display works
- Ensure artist associations update correctly on approval
- Test rejection workflow (no changes applied)

- **Success criteria:** Artwork record updates correctly; artists linked via `artwork_artists` table
- **Dependencies:** Task 1.2
- **Assigned to:** Backend Developer


#### Task 2.1: ArtistLookup Component ⭐ UX Priority

**Developer perspective:** Reusable composable for artist search

**UX perspective:** Typeahead must feel instant; mobile-friendly chips

- Debounced search input (300ms delay)
- Dropdown with artist results (name, short bio)
- Selected artists as removable chips (no ordering per Q14)
- "No results" state with helpful message (no create option per Q9/Q21)
- Keyboard navigation (arrow keys, Enter, Escape)
- Mobile-responsive (touch-friendly chip removal)
- **Implementation notes:**
  - Use `apiService.get('/artists/search', { q, limit: 10 })`
- **Success criteria:** Component tests pass; integrates with EditPage; accessible (ARIA labels)
- **Dependencies:** Task 1.1
- **Assigned to:** Frontend Developer

#### Task 2.2: ArtworkEditView Component ⭐ UX Priority
**Developer perspective:** New view following existing patterns (SubmitView, LogbookSubmissionView)
**UX perspective:** Form must be simple, clear validation, mobile-first design

  - Title (input, max 200 chars, char counter)
  - Description (textarea, **4x height = ~300px**, markdown hint, max 5000 chars)
  - Artists (ArtistLookup component, multiple selection)
  - Keywords (comma-separated input with tag suggestions)
  - Photos (read-only PhotoCarousel — show existing photos)
- **Actions:**
  - **Cancel** button (confirm if unsaved changes, navigate back)
  - **Save** button (validate, submit, show success toast)
  - Loading state during submission
  - Clear success message: "Your edit is pending curator review"
  - Error handling with helpful messages
- **Implementation notes:**
  - Use existing toast system for feedback
  - Reuse existing PhotoCarousel component
- **Success criteria:** Form validates; submits correctly; mobile-responsive; accessible
- **Dependencies:** Task 2.1, Task 1.2
**Developer perspective:** Add routes and conditional UI elements
**UX perspective:** Users must easily discover the edit feature

- **Deliverable:** Edit buttons and routing
- **Changes:**
  - Add route in `src/frontend/router/index.ts`: `/artwork/:id/edit`
  - Add "Edit Artwork" button in `ArtworkDetailView.vue` (next to existing actions)
  - Show button only for authenticated users (`authStore.isAuthenticated`)
  - Icon: pencil/edit icon for recognition
  - Mobile: ensure button is tap-friendly (min 44px height)
- **Success criteria:** Routes work; button visible to auth users; unauthorized users redirected to login
- **Dependencies:** Task 2.2
- **Assigned to:** Frontend Developer

#### Task 2.4: TagEditor Integration (Already Exists!)
**Developer perspective:** Reuse existing TagEditor component
- **Implementation:**
  - `TagEditor.vue` already exists (679 lines, fully featured!)
  - Add "Edit Tags" button in ArtworkDetailView's "Information & Details" section (per Q13)
  - Button opens TagEditor in a modal or navigates to `/artwork/:id/tags` route
- **Dependencies:** None (component exists)
- **Assigned to:** Frontend Developer

---
#### Task 3.1: Unit & Integration Tests
**Developer perspective:** Cover new components and API endpoints
**UX perspective:** Prevent regressions; ensure edit workflow is reliable

- **Deliverable:** Test coverage for new features
- **Frontend tests (Vitest + Vue Test Utils):**
  - ArtistLookup component (search, selection, removal, keyboard nav)
  - ArtworkEditView component (validation, submission, cancel flow)
  - Full edit workflow: submit edit → curator approves → artwork updated
- **Success criteria:** All tests pass; coverage ≥80% for new code; no regressions in existing tests
- **Dependencies:** All previous tasks
- **Assigned to:** QA + Developers
- **UX improvements:**
  - Smooth transitions (fade in/out for modals, loading states)
  - Helpful empty states ("No artists added yet — search to add")
  - Character counters with color coding (green → yellow → red)
- **Dependencies:** Task 3.1
- **Assigned to:** Frontend Developer + UX Designer

#### Task 3.3: Documentation & Deployment
**Developer perspective:** Update docs and deploy to staging
**UX perspective:** Clear user guide for submitting edits

- **Deliverable:** Updated documentation and staging deployment
- **Documentation updates:**
  - `/docs/api.md` — Add artist search endpoint examples
  - `/docs/frontend-architecture.md` — Document ArtworkEditView and ArtistLookup
  - `/docs/edit-workflow.md` (new) — User guide: "How to Edit Artwork"
  - [ ] Curator can review and approve edits (existing review UI)
- Artist display ordering (answer 14: timestamp order)
- Automated approval (all edits require curator approval per answer 2)
- Email notifications to curators (optional, not required for MVP)

---

## Handoff for next developer

If you're taking over this work, here's a compact guide to pick up where we left off and to finish the remaining tasks safely.

Quick goals for the next dev:
- Fix the remaining frontend test failures (currently isolated to ArtistLookup-related tests).
- Ensure the ArtistLookup SFC(s) are clean (no duplicate <template>/<script> blocks or stray markdown/code-fence fragments).
- Run the full test suite and address any other regressions.

Developer steps (runnable checklist):

1) Prepare environment
- Ensure Node.js and npm are installed (project uses node tooling in `src/frontend`).
- From the repo root run: `npm install` then `npm run build` to ensure dependencies and build artifacts are available.

2) Run the frontend tests locally (fast feedback loop)
- From repo root run the frontend test task: `npm run test:frontend` or change directory and run `cd src/frontend; npm run test`.
- For focused iteration run only the ArtistLookup tests to speed up cycles:
  - `cd src/frontend; npx vitest run src/components/__tests__/ArtistLookup.test.ts`

3) Known problem: ArtistLookup SFC parser error
- Symptom: Vitest fails with "Element is missing end tag." or "Single file component can contain only one <script setup> element." pointing at `ArtistLookup.vue`.
- Cause: Historically the file became corrupted with duplicate `<template>`/`<script setup>` blocks and stray markdown/code-fence fragments (for example, stray ```vue markers). Also two component locations exist in the tree: `src/frontend/components/ArtistLookup.vue` and `src/frontend/src/components/ArtistLookup.vue` to satisfy different import paths used in tests.
- Fix: Open both files and ensure each file contains exactly:
  - One `<template>` block.
  - One `<script setup lang="ts">` block (or `<script setup>` if TS not required for edits you make).
  - One optional `<style scoped>` block.
  - Remove any stray triple-backtick fences or markdown snippets.
  - Add a small guard in the selection helper to avoid indexing undefined items (example: `const item = results.value[highlighted.value]; if (!item) return; select(item);`).

4) Fast verification cycle
- After fixing an SFC, run the single test file above. When it passes, run the full frontend test suite: `cd src/frontend; npm run test`.

5) Worker/backend validation tests
- Worker-side tests are run from the repository root: `npm run test:workers`.
- New validation tests were added under `src/workers/routes/__tests__` (`submissions-edit.validation.test.ts`). These should pass; if they fail, inspect `src/workers/routes/submissions-new.ts` for validation logic.

6) Dev server and logs
- Start the dev server for local manual testing using the project's debug entry so logs are captured to `dev-server-logs.txt`:
  - `npm run devout` (this produces `dev-server-logs.txt` in the repo root). Use this when you want verbose worker logs while exercising the UI.

7) Debugging tips for tricky failures
- If Vitest shows odd runtime errors about `URL.createObjectURL` during map/icon tests, mock `URL.createObjectURL` in the test environment setup (node lacks this browser API). Example in a test setup file:
  - `global.URL.createObjectURL = () => 'blob:mock';`
- When imports fail like "Failed to resolve import '../components/ArtistLookup.vue'", check if tests import from `src/components` vs `components` — the repo intentionally has a duplicate path at `src/frontend/src/components` to satisfy some Vue test resolution; don't remove that copy until tests are green.

8) Deployment checklist
- Run full lint and tests: `npm run lint` and `npm run test` (both frontend and workers).
- Build workers: `npm run build:workers`.
- Build frontend assets: `npm run build:frontend`.
- Once green, follow `/docs/deployment.md` for staging and production deploy steps (wrangler config and secrets are documented there).

9) Contacts and context
- Primary technical contact: Steven (see `.github/instructions/steven.instructions.md` for process notes and conventions).
- Review the `docs/database.md` and `docs/photo-processing.md` for any DB and media handling implications.

10) Follow-ups and improvements (nice-to-have)
- Remove the duplicate component copy after ensuring all tests and import paths have been adjusted.
- Add keyboard/ARIA polish and additional integration tests for the artwork-edit approval flow.
- Add a small lint/format pre-check hook for SFCs to catch stray markdown fragments early.

Keep this file updated with your notes as you complete tasks — it's the single source of truth for this feature work.

---

## Progress update — frontend (in-progress)

Recent actions taken:
- Inspected and repaired multiple corrupted copies of `ArtistLookup.vue` (there are two paths used by tests: `src/frontend/components/ArtistLookup.vue` and `src/frontend/src/components/ArtistLookup.vue`). Overwrote these files with cleaned SFC content to remove duplicated `<template>`/`<script setup>` blocks and stray markdown fragments.
- Added unit tests for the ArtistLookup component at `src/frontend/components/__tests__/ArtistLookup.test.ts` (covers selection, removal, and debounce/fetch behaviour).
- Created a copy of the cleaned component under `src/frontend/src/components` to satisfy import resolution in `ArtworkDetailView.vue` tests.
- Ran the frontend test suite repeatedly to validate changes. Most tests pass; the failing suites are isolated to `components/__tests__/ArtistLookup.test.ts` and `src/views/__tests__/ArtworkDetailView.test.ts` with a parser error pointing at the ArtistLookup template (`SyntaxError: Element is missing end tag.`).

Current status:
- Todo `Fix ArtistLookup SFCs` is in-progress.
- Most frontend unit tests pass. Two suites still fail due to the SFC parsing error (likely caused by a leftover fragment in one of the SFC files or a test fixture importing the wrong path).

How to reproduce the failing tests locally (fast):
1. cd src/frontend
2. npx vitest run src/components/__tests__/ArtistLookup.test.ts

Immediate next steps:
- Re-open both `ArtistLookup.vue` files and remove any remaining stray fragments (triple backticks, extraneous angle-bracket fragments, or duplicate blocks). Confirm each file has exactly one `<template>`, one `<script setup lang="ts">`, and one optional `<style scoped>` block.
- Re-run the focused ArtistLookup test and iterate until green. Then run the full frontend suite.
- If parser errors persist, search for stray '```' or '```vue' fragments across the `src/frontend` tree and remove them.

Notes:
- When fixing SFCs, remember the test environment resolves imports from both `src/components` and `src/frontend/src/components`; keep both copies synchronized until imports are consolidated.
- I updated the project's todo list and set the ArtistLookup SFCs task to in-progress.